package com.footballnukes.moreorlessfootballers;

/**
 * Created by moshe on 18/04/2017.
 */

public class Category {
    private String name;
    private boolean purchased;
    private String description;
    private int score;

    public Category(String name, boolean purchased, String description, int score) {
        this.name = name;
        this.purchased = purchased;
        this.description = description;
        this.score = score;
    }

    public String getName() {
        return name;
    }

    public boolean isPurchased() {
        return purchased;
    }
    public String getDescription(){
        return description;
    }
    public int getScore(){
        return score;
    };
}