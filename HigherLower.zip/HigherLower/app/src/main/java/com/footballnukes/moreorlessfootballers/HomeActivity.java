package com.footballnukes.moreorlessfootballers;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Toast;
import android.widget.ViewSwitcher;

import java.util.ArrayList;

import beautifiers.FontTextView;
import beautifiers.GameButton;
import beautifiers.PlayButton;

/**
 * Created by moshe on 18/04/2017.
 */

public class HomeActivity extends AppCompatActivity {

    public static String FACEBOOK_URL = "https://www.facebook.com/ballboytv";
    public static String FACEBOOK_PAGE_ID = "634136046769198";

    ArrayList<Category> locked_cat,unlocked_cat;

    SharedPreferences sharedPreferences;
    SharedPreferences.Editor editor;
    RecyclerView rv_unlocked;

    GameButton remove_ads;

    LinearLayout ll_youtube,ll_facebook;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);


        sharedPreferences = this.getSharedPreferences("Download Data",0);
        editor = sharedPreferences.edit();
        editor.apply();


        rv_unlocked = findViewById(R.id.rv_unlocked);
        unlocked_cat = new ArrayList<>();
        unlocked_cat.add(new Category("Instagram",true,"Ronaldo vs Neymar",sharedPreferences.getInt("Instagram",0)));
        unlocked_cat.add(new Category("Market Value",true,"Messi vs Neymar",sharedPreferences.getInt("Market Value",0)));
        unlocked_cat.add(new Category("Goals This Season",true,"Ronaldo vs Neymar",sharedPreferences.getInt("Goals This Season",0)));
        unlocked_cat.add(new Category("Age",true,"Ronaldo vs Neymar",sharedPreferences.getInt("Age",0)));
        CategoryAdapter categoryAdapterUnlocked = new CategoryAdapter(unlocked_cat);
        rv_unlocked.setAdapter(categoryAdapterUnlocked);
        rv_unlocked.setLayoutManager(new LinearLayoutManager(this));
        rv_unlocked.setNestedScrollingEnabled(false);


        RecyclerView rv_locked = findViewById(R.id.rv_locked);
        locked_cat = new ArrayList<>();
        locked_cat.add(new Category("Twitter",false,"Ronaldo vs Neymar",sharedPreferences.getInt("Twitter",0)));
        locked_cat.add(new Category("Jersey Number",false,"Messi vs Neymar",sharedPreferences.getInt("Jersey Number",0)));
        locked_cat.add(new Category("Facebook",false,"Griezmann vs Pogba",sharedPreferences.getInt("Facebook",0)));
        locked_cat.add(new Category("Appearance",false,"Suarez vs Bale",sharedPreferences.getInt("Appearance",0)));
        locked_cat.add(new Category("FIFA Ranking",false,"Neuer vs De Gea",sharedPreferences.getInt("FIFA Ranking",0)));
        CategoryAdapter categoryAdapterLocked = new CategoryAdapter(locked_cat);
        rv_locked.setAdapter(categoryAdapterLocked);
        rv_locked.setLayoutManager(new LinearLayoutManager(this));
        rv_locked.setNestedScrollingEnabled(false);

        socialButtons();

    }

    private void socialButtons(){
        ll_facebook = findViewById(R.id.ll_facebook);
        ll_facebook.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent facebookIntent = new Intent(Intent.ACTION_VIEW);
                String facebookUrl = getFacebookPageURL(getApplicationContext());
                facebookIntent.setData(Uri.parse(facebookUrl));
                startActivity(facebookIntent);
            }
        });
        ll_youtube = findViewById(R.id.ll_youtube);
        ll_youtube.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse("http://www.youtube.com/c/theballboy")));
            }
        });
    }

    public class CategoryAdapter extends RecyclerView.Adapter<CategoryAdapter.ViewHolder> {

        private ArrayList<Category> mCategory;

        CategoryAdapter(ArrayList<Category> category) {
            mCategory = category;
        }

        @Override
        public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            Context context = parent.getContext();
            LayoutInflater inflater = LayoutInflater.from(context);
            View categoryView = inflater.inflate(R.layout.category_card, parent, false);
            return new ViewHolder(categoryView);
        }

        @Override
        public void onBindViewHolder(ViewHolder holder, int position) {
            final Category category = mCategory.get(position);

            FontTextView name = holder.name;
            FontTextView description = holder.description;
            FontTextView score = holder.score;
            ViewSwitcher viewSwitcher = holder.viewSwitcher;
            PlayButton playButton = holder.playButton;
            FrameLayout lock_frame = holder.lock_frame;
            ImageView iv_background = holder.iv_background;
            ImageView iv_border = holder.iv_border;

            name.setText(category.getName());
            description.setText(category.getDescription());
            score.setText(category.getScore()+"");


            playButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (!category.isPurchased()){
                        Toast.makeText(HomeActivity.this,"Coming Soon",Toast.LENGTH_SHORT).show();

                    }
                    else {
                        Intent game = new Intent(HomeActivity.this, GameActivity.class);
                        editor.putString("last", category.getName());
                        editor.apply();
                        startActivity(game);
                    }
                }
            });

            if (!category.isPurchased()){
                viewSwitcher.showNext();
                lock_frame.setVisibility(View.VISIBLE);
                iv_border.setImageResource(R.drawable.white_border);
                playButton.setText("Get");
                playButton.setCompoundDrawablesWithIntrinsicBounds(R.drawable.ic_getplus_drawable,0,0,0);
            }



            switch (category.getName()){
                case "Instagram":
                    iv_background.setImageResource(R.drawable.category_images_instagram);
                    break;
                case "Twitter":
                    iv_background.setImageResource(R.drawable.category_images_twitter);
                    break;
                case "Facebook":
                    iv_background.setImageResource(R.drawable.category_images_facebook);
                    break;
                case "Goals This Season":
                    iv_background.setImageResource(R.drawable.category_images_goals);
                    break;
                case "Appearance":
                    iv_background.setImageResource(R.drawable.category_images_appearance);
                    break;
                case "FIFA Ranking":
                    iv_background.setImageResource(R.drawable.category_images_fifa);
                    break;
                case "Market Value":
                    iv_background.setImageResource(R.drawable.category_images_value);
                    break;
                case "Jersey Number":
                    iv_background.setImageResource(R.drawable.category_images_jersey);
                    break;
                case "Age":
                    iv_background.setImageResource(R.drawable.category_images_age);
                    break;
            }


        }

        @Override
        public int getItemCount() {
            return mCategory.size();
        }

        // Provide a direct reference to each of the views within a data item
        // Used to cache the views within the item layout for fast access
        public class ViewHolder extends RecyclerView.ViewHolder{
            // Your holder should contain a member variable
            // for any view that will be set as you render a row
            private FontTextView name;
            private FontTextView description;
            private FontTextView score;
            private ViewSwitcher viewSwitcher;
            private PlayButton playButton;
            private FrameLayout lock_frame;
            private ImageView iv_background;
            private ImageView iv_border;

            // We also create a constructor that accepts the entire item row
            // and does the view lookups to find each subview
            public ViewHolder(View itemView) {
                // Stores the itemView in a public final member variable that can be used
                // to access the context from any ViewHolder instance.
                super(itemView);

                name = (FontTextView)itemView.findViewById(R.id.tv_category_name);
                description = (FontTextView)itemView.findViewById(R.id.tv_category_description);
                score = (FontTextView)itemView.findViewById(R.id.tv_score);
                viewSwitcher = (ViewSwitcher)itemView.findViewById(R.id.vs_score);
                playButton = (PlayButton)itemView.findViewById(R.id.bt_play);
                lock_frame = (FrameLayout)itemView.findViewById(R.id.fl_padlock);
                iv_background = (ImageView)itemView.findViewById(R.id.iv_category_background);;
                iv_border = (ImageView)itemView.findViewById(R.id.iv_category_border);
            }

        }
    }

    @Override
    protected void onResume() {
        rv_unlocked.getAdapter().notifyDataSetChanged();
        super.onResume();
    }

    public String getFacebookPageURL(Context context) {
        PackageManager packageManager = context.getPackageManager();
        try {
            int versionCode = packageManager.getPackageInfo("com.facebook.katana", 0).versionCode;
            if (versionCode >= 3002850) { //newer versions of fb app
                return "fb://facewebmodal/f?href=" + FACEBOOK_URL;
            } else { //older versions of fb app
                return "fb://page/" + FACEBOOK_PAGE_ID;
            }
        } catch (PackageManager.NameNotFoundException e) {
            return FACEBOOK_URL; //normal web url
        }
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        //CustomDialogClass cdd=new CustomDialogClass(HomeActivity.this);

        //cdd.show();
    }

}
